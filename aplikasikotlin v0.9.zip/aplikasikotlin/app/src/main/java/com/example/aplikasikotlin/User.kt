package com.example.aplikasikotlin

data class User(
    val uid: String = "",
    val fullname: String = "",
    val profileImage: String = "",
    val lastMessage: String = ""
)

