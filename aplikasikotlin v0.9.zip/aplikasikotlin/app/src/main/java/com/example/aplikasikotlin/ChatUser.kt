package com.example.aplikasikotlin

data class ChatUser(
    val userId: String = "",
    val userName: String = "",
    val userProfilePic: String = ""

)